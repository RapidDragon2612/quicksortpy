The QuickSortPy library (by RapidDragon2612) is a working python implementation of the quick sort algorithm.
Quick sort is widely considered to be the fastest and most efficient sorting algorithm.

To install QuickSortPy, run (in Command Prompt/Terminal):

pip install quicksortpy

To use QuickSortPy, run (in your python file):

import quicksortpy

And then use the quicksortpy.sort() function, with the argument of the array which is to be sorted:

quicksortpy.sort(example_array)

This will sort example_array. If you want to sort it in a new array, type:

quicksort.sort(example_array, True)

This will create a new array called sorted_arr .

You can also, for educational purposes, use the visualize() or visualise() function:

quicksort.visualize(example_array)

This will display all the steps that the quick sort algorithm took to sort the array.